import Cabecalho from "@/components/Cabecalho";

export default function Home() {
  return (
    <>
      <Cabecalho titulo="To do List" subtitulo="Aula 23" />
      <main>Hello, world!</main>
    </>
  );
}
